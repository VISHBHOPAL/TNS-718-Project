package Polymorphism_assing;

import java.util.Scanner;

public class Test_Bank_Project {
	
	public static void main(String[] args) {
		Accounts acc = new Accounts();
		acc.setAccountHolder("Vishal Verma");
		acc.setAccountNumber(344332222);
		acc.setBalance(0);
		
		String continueConndtion = "Yes";
		String condition = "Yes";
		
		
		do{
			Scanner kbs = new Scanner(System.in);
			

			System.out.println("Your Account Details are Shown Below");
			acc.displayAccountInfo();
			System.out.println("");	
		
			
			System.out.println("Press the options to perform the operation");
			System.out.println("Deposit");
			System.out.println("Withdraw");

			condition = kbs.next();
			
			if(condition.equalsIgnoreCase("deposit")) {
				System.out.println("===============================================");
				System.out.println("Enter the Amout to Deposit");

			
				acc.deposit(kbs.nextInt());
				System.out.println("============Amount Deposited===================================");
			}
			
			
			Accounts accountType = new Accounts();
			if(condition.equalsIgnoreCase("withdraw")) {
				System.out.println("from which account you want to withdraw ");
				System.out.println("Saving");
				System.out.println("Current");
				String chooseAccount = kbs.next();
				if(chooseAccount.equalsIgnoreCase("Saving")) {
					accountType=new SavingsAccount(acc);
					
				}else {
					accountType= new CurrentAccount(acc);
				}
				
				System.out.println("===============================================");
				System.out.println("Enter the Amout to Withdraw");

				int amount = kbs.nextInt();
				accountType.withdraw(acc, amount);
				System.out.println("============Amount Withdrawn===Remaining Anount============="+acc.balance);
			}
			
			Scanner scanner = new Scanner(System.in);
			System.out.println("Do you want to continue to run your program for bank application");
			continueConndtion = scanner.next();
			
		}while(continueConndtion.equalsIgnoreCase("Yes"));
   	  }

}
