package Polymorphism_assing;

public class SavingsAccount extends Accounts {

	static int maxTransaction=1;
	
	int remaingBalance = 0;
	
	SavingsAccount(Accounts acc){
		super(acc);
	}
	
	@Override
	public int withdraw(Accounts acc, int withAmount) {
		
		if(maxTransaction < 4) {
			remaingBalance = super.withdraw(acc, withAmount);
			maxTransaction++;
		}else {
			System.out.println("Maximum withdraw exceeeded for a month");
		}
		return remaingBalance;
	}


	

}
