package Polymorphism_assing;

public class CurrentAccount extends Accounts {
	
	CurrentAccount(Accounts acc){
		super(acc);
	}
	
}
