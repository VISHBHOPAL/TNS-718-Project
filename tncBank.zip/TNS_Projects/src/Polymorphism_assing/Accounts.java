package Polymorphism_assing;

import java.util.Scanner;

public class Accounts {

	private long accountNumber;
	private String accountHolder;
	protected int balance;
	
	 public Accounts() {
		 
	 }
	 
	 public Accounts(Accounts acc) {
	    this.accountNumber = acc.accountNumber; 
	    this.accountHolder = acc.accountHolder; 
	    this.balance = acc.balance; 
	 }
    
    
	void displayAccountInfo() {
		System.out.println("your Account Number is - " + "[" + getAccountNumber() + "]");
		System.out.println("your Name is - " + "[" + getAccountHolder() + "]");
		System.out.println("your Account balace is " + "[" + getBalance() + "]");
	}

	long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	
	public void setBalance(int balance) {
		this.balance = balance;

	}
	
	
	void deposit(int DepositAmount) {
		
		if(DepositAmount>0) {
			balance=balance+DepositAmount;		
			System.out.println("Account Balance -"+ balance);
		}
		
	}
	
	public int withdraw(Accounts acc, int withAmount) {
		if(acc.balance > withAmount)
			acc.balance= acc.balance-withAmount;
		return balance;		
	}
	
	public int getBalance() {
		return balance;
	}


}
