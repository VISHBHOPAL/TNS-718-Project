package TnsAssingment;

public class MathOperation {
	
	
	static int Add(int a ,int b) {
		
		return a+b;
	}
public static void main(String[] args) {
	MathOperation mo= new MathOperation();
	
	System.out.println(mo.Add(20, 20));
	
}
}
