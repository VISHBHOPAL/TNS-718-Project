package LibraryPackage;

public class LibraryBook {

	String title;
	String author;
	String isbn;
	boolean available;

	public LibraryBook(String booktitle, String bookauthor, String bookisbn) {

		title = booktitle;
		author = bookauthor;
		isbn = bookisbn;
		available=true;
	}

	void borrowBook() {
		
if(available) {
	available=false;
	System.out.println("book is borrowed"+title);
}else {
	
	System.out.println("sorry book is unavailable"+title);
}
	}

	public void returnBook() {
		
		if(!available) {
			available=true;
			System.out.println("book is return available");
	
	
}
	}


public static void main(String[] args) {
	LibraryBook L1= new LibraryBook("shivaay", "valmiki", "indian");
	LibraryBook L2= new LibraryBook("jbk", "kiran sir", "indian");

	
	L1.borrowBook();
	L2.borrowBook();
	L2.returnBook();
}
}
